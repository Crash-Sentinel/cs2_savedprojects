#ifndef RECTANGLE_HPP
#define RECTANGLE_HPP

/*
Include clauses, and a using declaration
for easier typing and documentation of fabs
*/
#include <cassert>
#include <cmath>

using std::fabs;

/*
    structure Point for following the
    rectangle_main.cpp file as well as
    better memory
*/
struct Point
{
    double x;
    double y;

    /*
    @brief Point constructor for assertions and creating points

    Preconditions:
    @param x (double) -> the X cartesian coordinate value
    @param y (double) -> the Y cartesian coordinate value

    Postconditions:
    Returns none -> Constructor initializes
    */
    Point(double x = 0.0f, double y = 0.0f) : x(x), y(y) {
        assert(
            x == fabs(x) &&
            y == fabs(y) &&
            x <= static_cast<double>(20.0) &&
            y <= static_cast<double>(20.0)
        );
    }
};

/*
@brief (Sophisticated) Rectangle Class, named Rectangle
to follow rectangle_main.cpp as well

All definitions are given in the rectangle.cpp file
so to avoid confusion, I'll document them all in there

Preconditions:
@param None

Postconditions:
@return None (Initializes Sophisticated Rectangle Class)
*/
class Rectangle
{
    private:
        Point p1, p2, p3, p4;        

    public:
        Rectangle(
            Point p1,
            Point p2,
            Point p3,
            Point p4
        );

        double length();
        double width();
        double perimeter();
        double area();
        bool square();

        void setCoord(
            Point p1,
            Point p2,
            Point p3,
            Point p4
        );
};

#endif