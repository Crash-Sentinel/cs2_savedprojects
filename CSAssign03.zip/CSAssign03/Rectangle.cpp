#include "./Rectangle.hpp"

/*
Potential Improvement: 
Creating new member variables length and width
to avoid recomputation of such variables within function
calls. Not done here to abide by assignment criteria.
*/


/*
@brief Constructor for Sophisticated Rectangle Class,
also asserts that the points do create a rectangle

Preconditions: None
Postconditions: None (Rectangle Object is created)
*/
Rectangle::Rectangle(
    Point p1, Point p2, Point p3, Point p4
)
{
    assert(
        (
            p1.x == p4.x &&
            p1.y == p2.y &&
            p2.x == p3.x &&
            p4.y == p3.y
        )
    );

    this->p1 = p1;
    this->p2 = p2;
    this->p3 = p3;
    this->p4 = p4;
};

/*
@brief Returns the longer side of the rectangle object
by calculating which side of P1->P4 or P1->P2 is longer
(
Other calculations are unnecessary since given its a rectangle
P1->P4 == P2->P3 and
P1->P2 == P3->P4
)

Preconditions: None (Given that a Rectangle Object is initialized)
Postconditions: Returns the longer side of the rectangle object
*/
double Rectangle::length()
{
    double length = fabs(p2.x - p1.x);
    double width = fabs(p1.y - p4.y);

    return (length > width) ? length : width;
};

/*
@brief Returns the shorter side of the rectangle object
by calculating which side of P1->P4 or P1->P2 is longer
(
Other calculations are unnecessary since given its a rectangle
P1->P4 == P2->P3 and
P1->P2 == P3->P4
)

Preconditions: None (Given that a Rectangle Object is initialized)
Postconditions: Returns the shorter side of the rectangle object
*/
double Rectangle::width()
{
    double length = fabs(p2.x - p1.x);
    double width = fabs(p1.y - p4.y);

    return (length < width) ? length : width;
};


/*
@brief Returns the (sum) perimeter of the rectangle object
(
Other calculations are unnecessary since given its a rectangle
P1->P4 == P2->P3 and
P1->P2 == P3->P4
)

Preconditions: None (Given that a Rectangle Object is initialized)
Postconditions: Returns the perimeter side of the rectangle object
*/
double Rectangle::perimeter()
{
    double length = fabs(p2.x - p1.x);
    double width = fabs(p1.y - p4.y);

    return 2 * (width + length);
};

/*
@brief Returns the area of the rectangle object
(
Other calculations are unnecessary since 
the area of a rectangle can be found with
the produce of one length or one width
)

Preconditions: None (Given that a Rectangle Object is initialized)
Postconditions: Returns the area of the rectangle object
*/
double Rectangle::area()
{
    double length = fabs(p2.x - p1.x);
    double width = fabs(p1.y - p4.y);

    return width * length;
};

/*
@brief Returns a boolean whether the rectangle object constitutes a square
(
Other calculations are unnecessary since 
if one side doesn't equal another then it is known to not be a square
)

Preconditions: None (Given that a Rectangle Object is initialized)
Postconditions: Returns whether the rectangle object constitutes a square
*/
bool Rectangle::square()
{
    return (fabs(p2.x - p1.x) == fabs(p1.y - p4.y));
};

/*
@brief Mutation / Setter function for setting new cartesian coordinates
for pointers

Preconditions: None (Given that a rectangle class is initialized)
Postconditions: Given rectangle object now contains new coordinates set by user
*/
void Rectangle::setCoord(
    Point p1,
    Point p2,
    Point p3,
    Point p4
) 
{
    this->p1 = p1;
    this->p2 = p2;
    this->p3 = p3;
    this->p4 = p4;
};