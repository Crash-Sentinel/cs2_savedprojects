#include "MyDataStructure.hpp"

namespace CS2
{
    double averageGPA(Student students[], int studentNumber);
    //Goal: to calculate average gpa from an array of Student
    //students: the array of Student
    //studentNumber: size of the array students
    //the function returns the average gpa
}