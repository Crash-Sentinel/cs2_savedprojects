#include "./../Headers/MyLibrary.hpp"
namespace CS2
{
    double averageGPA(Student students[], int studentNumber)
    {
        double totalGPA = 0; //initialize to 0 before do the summation
        for (int i = 0; i < studentNumber; i++) {
            totalGPA += students[i].OveralGPA;
        }
        return totalGPA / static_cast<double>(studentNumber);
    }
}