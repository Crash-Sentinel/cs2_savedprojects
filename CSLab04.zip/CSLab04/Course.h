#ifndef COURSE_H
#define COURSE_H

#include <string>
namespace ComputerScience
{
    class Course
    {
    private:
        std::string courseName;
        std::string department;
        int credit;
        int scoreNumber;  // store the size of the array scores
        int *scores;      // store the address of dynamically allocated array for scores

    public:
        Course();  // default constructor
        Course(std::string courseName, std::string department, int credit);  // constructor
        Course(const Course& a); // must use reference parameter to avoid copying object
        ~Course();  // destructor. Will be automatically called when the object is destroyed
        Course& operator=(const Course& a); //return type must be the reference of itself
                                            //to support consecutive assignment such as a=b=c;

        std::string getCourseName() const
        {
            return courseName;  // note this function is an inline function
        }

        // you can also add keyword inline to specify inlined function
        inline std::string getDepartment() const
        {
            return department;
        }

        int getCredit() const;
        void setCourseName(std::string courseName);
        void setDepartment(std::string department);
        void setCredit(int credit);
        void setNumberOfScores(int number);  // set the number of scores and dynamically allocate
        int getNumberOfScores() const;       // get the number of scores
        void setScore(int index, int aScore);  // set the score at the array position index
        int getScore(int index) const;  // get the score at position index of the array
        double getAverageScore() const;  // get the average. Return type double to retain decimal

    private:
        // helper functions here
        void freeMemory();  // clear the memory allocated
        void contentCopy(const Course& a); // copy content from variable a
    };
}

#endif // COURSE_H
