#include <iostream>
#include "Course.h"
void printCourse(const ComputerScience::Course& a);
using namespace std;

/*
Name: Bennett Miller bzm3@uakron.edu
Purpose: Demonstrate copy and assignment constructors and how
dynamic memory allocation and pointers may affect such processes
*/

int main()
{
    using ComputerScience::Course;
    string name = "Computer Science II";
    string depart = "Computer Science";
    {
        Course cs2;
        printCourse(cs2);
        cout << endl;cout << endl;
        cs2.setCourseName(name);
        cs2.setDepartment(depart);
        cs2.setCredit(4);
        cs2.setNumberOfScores(3); // set three scores
        cs2.setScore(0,95);
        cs2.setScore(1,97);
        cs2.setScore(2,100);
        printCourse(cs2);
        cout << endl; cout << endl;
        cs2.setNumberOfScores(2); // reset scores
        cs2.setScore(0,60);
        cs2.setScore(1,70);
        cout << "After reset scores:\n";
        printCourse(cs2);

        Course previousCS2(cs2);
        Course nextCS2;
        nextCS2 = cs2;
        cout << "\nprevousCS2 after declared:\n";
        printCourse(previousCS2);
        cout << "\nnextCS2 after assigned:\n";
        printCourse(nextCS2);
        //change a score in cs2
        cs2.setScore(0, 100);
        cout << "\ncs2 after score at position 0 is changed:\n";
        printCourse(cs2);
        cout << "\npreviousCS2 after score at position 0 of cs2 is changed:\n";
        printCourse(previousCS2);
        cout << "\nnextCS2 after score at position 0 of cs2 is changed:\n";
        printCourse(nextCS2);
    }
    cout << "\n\nEnter RRTURN key to finish the program";
    cin.get();
    return 0;
}

void printCourse(const ComputerScience::Course& a)
{
    cout << "\"" << a.getCourseName() << "\" of "
         << a.getDepartment() << " Department has "
         << a.getCredit() << " credits  "
         << "It contains " << a.getNumberOfScores() << " scores with average " << a.getAverageScore(); 
}