#include <iostream>

int main()
{
    std::cout << "Hello world from Bennett Miller!";
    return 0;
}