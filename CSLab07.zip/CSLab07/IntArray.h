/*
    Bennett Miller @ bzm3@uakron.edu
    4/13/2025

    Brief: Implement a proper implementation of IntArray using Linked Lists
    and showcase differences between array and it's linked list implementation
*/

#ifndef INTARRAY_H
#define INTARRAY_H
#include <iostream>

namespace ComputerScience
{
    class IntArray
    {
        private:
            int length; // hold the array size. i.e. the number of nodes
            struct ListNode
            {
                int value; //hold the value
                ListNode* previous, *next;
                //previous: pointing to the previous node
                //next: pointing to the next node
            };
            ListNode* first; // hold the address of first node
            ListNode* last; //hold the address of last node
            ListNode* current; //hold the address of current node. Think as a cursor
            int currentIndex; // the array index value of the node that current points to
            //implementation code must maintain the consistency of currentIndex and current
        public:
            IntArray(int length = 0); //constructor. length is the array size. default is 0
            IntArray(const IntArray& r); //copy constructor to initiate the instance from existing instance
            ~IntArray(); // destructor. Allocated array must be deleted in this function
            int size() const; //getter function to return the size of the array
            int& operator[](int i); //subscript operator overloading. the return value must be the reference of the element of the array
            IntArray& operator=(const IntArray& r); //overloading operator =
            IntArray operator+(const IntArray& r) const; //overloading operator + to merge two IntArrays
            IntArray operator+(int) const; //overloading operator + to add an int element at the end of the array
            IntArray& operator+=(const IntArray& r); //overloading operator += to append an array
            IntArray& operator+=(int); //overloading operator += to append an int to the end of the array
            void Resize(int newSize); //Resize the array to the length of newSize. It preserves the existing values
            friend std::ostream& operator<<(std::ostream & out, const IntArray& r); // friend function to overload operator << for output
            friend std::istream& operator >> (std::istream & in, IntArray& r); //friend fuction to overloado operator >> for input
            friend IntArray operator+(int, const IntArray&); // commutative + of IntArray operator+(int)
        private:
            void copyContent(const IntArray& r); //copy the content from another object
            void addNodes(int num); //add num nodes (place holder) to the end of the list
            void removeNodes(int num); // remove num nodes from the end of the list
    };
}

#endif // INTARRAY_H