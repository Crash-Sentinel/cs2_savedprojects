#include "IntArray.h"
#include <iostream>

namespace ComputerScience {

    void IntArray::addNodes(int num) {
        if (num < 0) return;

        // Add 'num' nodes to the end of the list
        ListNode *newNode;
        for (int i = 0; i < num; i++) {
            // Create a node. Leave value unassigned because it is a placeholder
            newNode = new ListNode;
            newNode->next = nullptr;
            newNode->previous = nullptr;

            // Add to the list
            if (last == nullptr) { // Empty list
                first = last = newNode;
            } else {
                last->next = newNode;  // Make current last node point to newNode
                newNode->previous = last;  // Make newNode point back to last node
                last = newNode;  // Update last to be newNode
            }
        }

        length += num;  // Increase length of the array

        // Check and update currentIndex if necessary
        if (currentIndex < 0 && length > 0) {
            currentIndex = 0;
            current = first;
        }
    }

    void IntArray::removeNodes(int num) {
        if (num < 0) return;

        // Remove 'num' nodes from the end of the list
        if (num > length) num = length;

        ListNode *tmp;
        for (int i = 0; i < num; i++) {
            if (last->previous == nullptr) {  // Only one node remaining
                delete last;
                first = last = nullptr;
            } else {
                tmp = last;
                last = last->previous;  // Move back one node
                last->next = nullptr;
                delete tmp;  // Free the space
            }
        }

        length -= num;  // Decrease the length of the array

        if (currentIndex > length - 1) {
            current = last;  // If current node was removed, update current pointer
            currentIndex = length - 1;
        }
    }

    // Constructor
    IntArray::IntArray(int size) {
        length = 0;
        first = last = current = nullptr;
        currentIndex = -1;

        if (size < 0) {
            std::cout << "Size of the array must be greater than 0";
        } else if (size == 0) {
            // Do nothing, already initialized
        } else {
            addNodes(size);  // Add placeholders
            currentIndex = 0;  // Point current to first node
            current = first;
        }
    }

    // Destructor
    IntArray::~IntArray() {
        removeNodes(length);
    }

    // Copy constructor
    IntArray::IntArray(const IntArray &r) {
        length = 0;
        first = last = current = nullptr;
        currentIndex = -1;
        copyContent(r);  // Copy all elements
    }

    // Assignment operator overloading
    IntArray& IntArray::operator=(const IntArray &r) {
        if (this == &r) return *this;  // Do nothing if self-assignment

        removeNodes(length);  // Clean the list
        copyContent(r);  // Copy all
        return *this;
    }

    // Copy content from another object (internal use)
    void IntArray::copyContent(const IntArray &r) {
        if (r.length == 0) return;  // No nodes to copy

        if (r.length > length) {
            addNodes(r.length - length);  // Add placeholders
        } else if (r.length < length) {
            removeNodes(length - r.length);  // Remove extra nodes
        }

        // Copy contents
        ListNode *n1 = first;
        ListNode *n2 = r.first;
        for (int i = 0; i < length; i++) {
            n1->value = n2->value;
            n1 = n1->next;
            n2 = n2->next;
        }

        currentIndex = 0;
        current = first;  // Point current to first node
    }

    // Getter function to return the size of the array
    int IntArray::size() const {
        return length;
    }

    // Overloading operator[] to access elements
    int& IntArray::operator[](int i) {
        if (i < 0 || i >= length) {
            std::cout << "The index is out of range.";
            exit(1);  // Error: index out of range
        }

        // Make variable current point to the i-th node
        if (i == currentIndex + 1) {
            current = current->next;
            currentIndex++;
        } else if (i == currentIndex - 1) {
            current = current->previous;
            currentIndex--;
        } else {
            // Move to the i-th node by either moving forward or backward
            current = (i < currentIndex) ? first : last;
            currentIndex = (i < currentIndex) ? 0 : length - 1;
            while (currentIndex != i) {
                current = (currentIndex < i) ? current->next : current->previous;
                currentIndex += (currentIndex < i) ? 1 : -1;
            }
        }

        return current->value;
    }

    // Overloading operator += to append
    IntArray& IntArray::operator+=(const IntArray& r) {
        ListNode *p1 = last;
        ListNode *p2 = r.first;
        for (int i = 0; i < r.length; i++) {
            addNodes(1);
            p1->next->value = p2->value;
            p1 = p1->next;
            p2 = p2->next;
        }
        return *this;
    }

    // Resizing the array
    void IntArray::Resize(int newSize) {
        if (newSize <= 0) {
            std::cout << "Array size must be a positive number.";
            return;
        }

        if (newSize > length) {
            addNodes(newSize - length);
        } else {
            removeNodes(length - newSize);
        }
    }

    // Friend function for output operator <<
    std::ostream& operator<<(std::ostream &out, const IntArray &r) {
        IntArray::ListNode *p = r.first;
        for (int i = 0; i < r.length; i++) {
            out << p->value << ' ';
            p = p->next;
        }
        return out;
    }

    // Friend function for input operator >>
    std::istream& operator>>(std::istream &in, IntArray &r) {
        IntArray::ListNode *p = r.first;
        for (int i = 0; i < r.length; i++) {
            in >> p->value;
            p = p->next;
        }
        return in;
    }

}  // End namespace ComputerScience
