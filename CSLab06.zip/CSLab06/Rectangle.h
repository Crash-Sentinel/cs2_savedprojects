#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <iostream>

class Rectangle
{
    public:
        Rectangle();
        Rectangle(double, double);
        void setLength(double);
        void setWidth(double);
        double getLength() const;
        double getWidth() const;
        double getArea() const;
        friend std::ostream& operator<<(std::ostream&, const Rectangle&);
        friend std::istream& operator>>(std::istream&, Rectangle&);

        // Rectangle operator-(const Rectangle&);
        // friend Rectangle operator+(int, const Rectangle&);
        // Rectangle operator+(const Rectangle&);
    private:
        double length, width;
};

#endif //RECTANGLE_H