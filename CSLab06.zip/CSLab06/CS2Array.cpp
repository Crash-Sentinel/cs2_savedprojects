#ifndef CS2ARRAY_H
#define CS2ARRAY_H

// #include <iostream>
#include ".\CS2Array.h"

namespace ComputerScience
{
    template <class T>
    CS2Array<T>::CS2Array(int size)
    {
        //constructor
        if (size < 0)
        {
            //not allowed
            length = 0;
            myArray = nullptr;
            std::cout << "size of the array must be greater than 0";
        }
        else if (size == 0)
        {
            length = 0;
            myArray = nullptr;
        }
        else
        {
            length = size;
            myArray = new T[size];
        }
    }

    template <class T>
    CS2Array<T>::~CS2Array()
    {
        //myArray always holds a memory, so safe to free
        freeMemory();
    }

    template <class T>
    void CS2Array<T>::freeMemory()
    {
        //free the allocated memory for myArray
        if (myArray != nullptr)
        {
            delete [] myArray;
            myArray = nullptr;
            length = 0;
        }
    }

    template <class T>
    CS2Array<T>::CS2Array(const CS2Array<T> & r) {
        //copy constructor to initiate the instance from existing instance
        copyContent(r); // copy all
    }

    template <class T>
    CS2Array<T>& CS2Array<T>::operator=(const CS2Array<T>& r) {
        if (this == &r) { //this is the pointer to itself
            //the address of itself is the same as the address of object a
            // it is doing a=a. So do nothing
            return *this; // return this object
        }
        //now the right side CS2Array r is not the same object
        freeMemory(); //clean current array
        copyContent(r); //copy all
        return *this; //return the reference of the object
    }
    
    template <class T>
    void CS2Array<T>::copyContent(const CS2Array<T>& r) {
        // copy the content from another object

        //handle array
        if(r.length == 0)
        {
            //r is empty array
            length = 0;
            myArray = nullptr;
        }else{
            //only allocate memory and copy array when r.length is not 0
            length = r.length;
            myArray = new T[length];
            for (int i=0; i<length; i++) {
                myArray[i] = r.myArray[i]; //copy array elements
            }
        }
    }
    template <class T>
    int CS2Array<T>::size() const {
        //getter function to return the size of the array
        return length;
    }
    template <class T>
    T& CS2Array<T>::operator[](int i) {
        //subscript overloading, return the reference of i th element
        if (i < 0 || i >= length) {
            //out of range
            std::cout << "the index is out of range";
        }
        return myArray[i];
    }
    template <class T>
    CS2Array<T> CS2Array<T>::operator+(const CS2Array<T>& r) const {
        //overloading operator + to merge two CS2Arrays
        //create an instance.
        CS2Array merged(length + r.length);

        //copy content from this object first
        for(int i=0; i<length; i++) {
            merged.myArray[i] = myArray[i];
        }
        //copy content from r
        for (int i=0; i<r.length; i++) {
            merged.myArray[length + i] = r.myArray[i];
        }
        return merged;
    }
    template <class T>
    CS2Array<T> CS2Array<T>::operator+(T val) const{
        //overloading operator + to merge CS2Arrays and an int
        CS2Array<T> merged(length + 1); //create an array one element more than this array
        //copy content from this object first
        for (int i=0; i<length; i++) {
            merged.myArray[i] = myArray[i];
        }
        //put val to the last element
        merged.myArray[length] = val;
        return merged;
    }
    template <class T>
    CS2Array<T>& CS2Array<T>::operator+=(const CS2Array<T>& r) {
        //overloading operator += to append r to this array
        if(r.length == 0) {
            //appended array is empty. return the reference of this object directly
            return *this;
        }
        //following code works for both a += a; and a += b;
        //create a new combined array to hold merged arrays
        int newlength = length + r.length;
        T *tmpArray = new T[newlength];
        //copy contents from this object into tmpArray
        for (int i=0; i<length; i++) {
            tmpArray[i] = myArray[i];
        }
        //copy content from r
        for (int i=0; i<r.length; i++) {
            tmpArray[length + i] = r.myArray[i];
        }

        //free current array of this object
        freeMemory();
        //swap tmpArray to myArray
        myArray = tmpArray;
        length = newlength;
        return *this;
    }
    template <class T>
    CS2Array<T>& CS2Array<T>::operator+=(T val) {
        //overloading operator += to append an int to this array
        //create a new array one element larger
        int newlength = length + 1;
        T *tmpArray = new T[newlength];
        //copy contents from this object into tmpArray
        for (int i=0; i<length; i++) {
            tmpArray[i] = myArray[i];
        }

        //put val to the last element of tmpArray
        tmpArray[length] = val;

        //free current array of this object
        freeMemory();
        //swap tmpArray to myArray
        myArray = tmpArray;
        length = newlength;
        return *this;
    }

    template <class T>
    std::ostream& operator<<(std::ostream & out, const CS2Array<T>& r) // friend function to overload operator << for output
    {
        // friend function to overload operator << for output
        for (int i=0; i<r.length; i++)
        {
            out << r.myArray[i] << ' ';
        }
        return out;
    }
}
#endif