#include "Rectangle.h"
#include <iostream>

Rectangle::Rectangle()
{
    length = width = 0;
}
Rectangle::Rectangle(double length, double width)
{
    this->length = length;
    this->width = width;
}
void Rectangle::setLength(double length)
{
    this->length = length;
}
void Rectangle::setWidth(double width)
{
    this->width = width;
}
double Rectangle::getLength() const 
{
    return length;
}
double Rectangle::getWidth() const
{
    return width;
}
double Rectangle::getArea() const
{
    return length * width;
}
std::ostream& operator<<(std::ostream& out, const Rectangle& r)
{
    out << "(" << r.length << ", " << r.width << ")";
    return out;
}
std::istream& operator>>(std::istream& in, Rectangle& r)
{
    in >> r.length >> r.width;
    return in;
}
