#ifndef CS2Array_H
#define CS2Array_H
#include <iostream>

namespace ComputerScience
{
    template <class T> class CS2Array;

    template <class T>
    std::ostream& operator<< (std::ostream & out, const CS2Array<T>& r);

    template <class T>
    class CS2Array
    {
        private:
            int length; //hold the array size
            T * myArray; //a pointer pointing to a dynamically allocated array.
        public:
            CS2Array(int length = 0); // constructor. length is the array size, default to 0
            CS2Array(const CS2Array& r); //copy constructor to initialize the instance from existing instance
            ~CS2Array(); //destructor. Allocated array must be deleted in this function
            int size() const; //getter function to return the size of the array
            T& operator[](int i); //subscript operator overloading. The return value must be the reerence of the element of the array
            CS2Array<T>& operator=(const CS2Array& r); //operator overloading =
            CS2Array operator+(const CS2Array& r) const; //operator overloading + to merge two CS2Arrays
            CS2Array operator+(T) const; //overloading operator + to add an int element at the end of the array
            CS2Array& operator+=(const CS2Array& r); //overloading operator += to append an array
            CS2Array& operator+=(T); //overloading operator += to append an int to the end of the array

            friend std::ostream& operator<< <>(std::ostream& out, const CS2Array& r); // friend function to overload operator << for output

            friend std::istream& operator >> (std::istream & in, CS2Array& r) //friend function to overload operator >> for input
            {    
                for (int i = 0; i < r.length; i++)
                {
                    in >> r.myArray[i];
                }
                return in;
            }

            friend CS2Array operator+(T val, const CS2Array& r) //commutative + of CS2Array operator+(T)
            {
                //commutative + of CS2Array operator+(T)
                CS2Array merged(r.length + 1); // create an array one element more than this array
                merged.myArray[0] = val;
                //copy content from this object
                for (int i = 0; i < r.length; i++) {
                    merged.myArray[1+i] = r.myArray[i];
                }
                return merged;
            }

        private:
            void freeMemory(); //free the allocated memory for myArray
            void copyContent(const CS2Array& r); //copy the content from another object
    };
}

#include "CS2Array.cpp"

#endif // CS2Array_H