// COPYRIGHT (C) 2025 Bennett Miller ( 4804913 ) All rights reserved.
//
// rational.hpp: Definition of rational class and its interace.

#include "rational.hpp"

#include <iostream>


// -------------------------------------------------------------------------- //
// Helper functions

// Compute the GCD (greatest common divider) of two integer values using Euclid's algorithm.
int
gcd(int a, int b)
{
  a = abs(a);   //make them to be positive numbers
  b = abs(b);
  if(a==0 || b==0){ //if one number is 0, always return 1
    return 1;
  }
  while (b != 0) {
    int t = b;
    b = a % b;
    a = t;
  }
  return a;
}


// Compute the LCM (Least Common Multiple) of two integer values.
int
lcm(int a, int b)
{
  a = abs(a); //make them positive
  b = abs(b);
  if(a == 0 || b == 0){
    throw "Integers can not be zero in calculating Least Common Multiple";
  }
  return (abs(a) / gcd(a, b)) * abs(b);
}

// -------------------------------------------------------------------------- //
// Rational implementation

Rational::Rational() : numer(0), denom(1) {};

Rational::Rational(int a): numer(a), denom(1) {};

Rational::Rational(int a, int b)
{
  if (b == 0) throw "Denominator cannot be 0";
  if (abs(b) != b) b = -b;

  int greatest = gcd(a, b);

  a /= greatest;
  b /= greatest;

  numer = a;
  denom = b;
}


bool Rational::operator==(const Rational& other)
{
  return (this->numer == other.num() && this->denom == other.den()) ? true : false;
}

bool Rational::operator!=(const Rational& other)
{
  return (*this == other);
}

bool Rational::operator<(const Rational& other)
{
  return ((static_cast<double>(numer) / denom) < (static_cast<double>(other.num()) / other.den()));
}

bool Rational::operator>(const Rational& other)
{
  return ((static_cast<double>(numer) / denom) > (static_cast<double>(other.num()) / other.den()));
}

bool Rational::operator<=(const Rational& other)
{
  return ((static_cast<double>(numer) / denom) <= (static_cast<double>(other.num()) / other.den()));
}

bool Rational::operator>=(const Rational& other)
{
  return ((static_cast<double>(numer) / denom) >= (static_cast<double>(other.num()) / other.den()));
}

Rational Rational::operator+(const Rational& other) const
{
  int lcmult = lcm(denom, other.den());

  int numA = numer * lcmult;
  return Rational(numA + numer, lcmult);


};

Rational Rational::operator-(const Rational& other) const
{
  int lcmult = lcm(denom, other.den());
  int numA = numer * lcmult;
  return Rational(numA - other.num(), lcmult);
}

Rational Rational::operator*(const Rational& other) const
{
  return Rational(numer * other.num(), denom * other.den());
}

Rational Rational::operator/(const Rational& other) const
{
  return *this * Rational(other.den(), other.num());
}

//Friend functions

Rational operator+(const int a, const Rational& other)
{
  return Rational((a * other.den()) + other.num(), other.den());
}

Rational operator-(const int a, const Rational& other)
{
  return Rational((a * other.den()) - other.num(), other.den());
}

Rational operator*(const int a, const Rational& other)
{
  return Rational(a * other.num(), other.den());
}

Rational operator/(const int a, const Rational& other)
{
  return Rational(a * other.den(), other.num());
}

std::ostream&
operator<<(std::ostream& os, Rational r)
{
  if (r.den() != 1)
  {
    return os << r.num() << '/' << r.den();
  }
  else
  {
    return os << r.num();
  }
}

//DO NOT CHANGE operators >> overloading function
std::istream&
operator>>(std::istream& is, Rational& r)
{
  // Read the first integer, return on error.
  int p;
  is >> p;
  if (!is)
    return is;

  // Check for the divider. Assuming no spaces.
  if (is.peek() != '/') {
    r = Rational(p);
    return is;
  }
  is.get();

  int q;
  is >> q;
  if (!is)
    return is;
  if (q == 0) {
    is.setstate(std::ios::failbit);
    return is;
  }
  r = Rational(p, q);
  return is;
#if 0
  int p, q;
  char c;
  is >> p >> c >> q;
  if (!is)
    return is;
  // Require that the divider to be a '/'.
  if (c != '/') {
    is.setstate(std::ios::failbit);
    return is;
  }

  // Make sure that we didn't read p/0.

  r = Rational(p, q);
  return is;
#endif
}