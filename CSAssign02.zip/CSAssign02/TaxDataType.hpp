#ifndef TAXDATATYPE_HPP
#define TAXDATATYPE_HPP

struct taxPayer
{
    float taxRate;
    float income;
    float taxes;
};

#endif