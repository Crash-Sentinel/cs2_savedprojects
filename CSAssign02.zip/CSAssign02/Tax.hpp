#ifndef TAX_HPP
#define TAX_HPP

#include "TaxDataType.hpp"

void taxPrint(taxPayer* arr, const int SIZE);
void taxTaker(taxPayer* arr, const int SIZE);

#endif