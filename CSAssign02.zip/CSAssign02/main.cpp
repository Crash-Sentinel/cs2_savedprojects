#include "Tax.hpp"
#include "TaxConstants.hpp"

int main()
{
    taxPayer array[TAXCONSTANTS::EXAMPLE_SIZE];

    taxTaker(array, TAXCONSTANTS::EXAMPLE_SIZE);
    taxPrint(array, TAXCONSTANTS::EXAMPLE_SIZE);

    return 0;
}