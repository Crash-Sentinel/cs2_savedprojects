#include "TaxConstants.hpp"
#include "Tax.hpp"
#include <iostream>
#include <iomanip>

using std::cout;
using std::cin;

void taxPrint(taxPayer* arr, const int SIZE)
{
    cout << "Taxes due for this year: ";

    for (int i = 0; i < SIZE; ++i)
    {
        cout << "Tax Payer # " << i+1 << ": $ " << 
        std::fixed << std::setprecision(2) << arr[i].taxes << "\n";
    }
}

void taxTaker(taxPayer* arr, const int SIZE)
{
    cout << "Please enter the annual income and tax rate for 2 tax payers:\n\n";
    
    for (int i = 0; i < SIZE; ++i)
    {
        cout << "Enter this year's income for tax payer " << i+1 << ": ";
        cin >> arr[i].income;
        cout << "Enter the tax rate for tax payer # " << i+1 << ": ";
        cin >> arr[i].taxRate;
        cout << "\n\n";
        arr[i].taxes = arr[i].income * arr[i].taxRate;
    }
}