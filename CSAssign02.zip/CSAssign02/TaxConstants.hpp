#ifndef TAXCONSTANTS_HPP
#define TAXCONSTANTS_HPP

namespace TAXCONSTANTS
{
    const int SIZE = 4;
    const int EXAMPLE_SIZE = 2;
}

#endif