#include <iostream>
#include "Course.h"

void printCourse(const ComputerScience::Course& a);

using namespace std;

int main ()
{
    using ComputerScience::Course;
    string name = "Computer Science II";
    string depart = "Computer Science";
    {
        // Course cs2;
        // Course cs2("System Programming", "Computer Science", 3);
        // printCourse(cs2);
        // cout << endl;
        // cs2.setCourseName(name);
        // cs2.setDepartment(depart);
        // cs2.setCredit(4);
        // printCourse(cs2);

        // Course futureYearCS2(cs2);
        // cout << "\n futureYearCS2 is ";
        // printCourse(futureYearCS2);

        // Course previousYearCS2 = cs2;
        // cout << "\n previousYearCS2 is ";
        // printCourse(previousYearCS2);

        Course *cs2Ptr;
        cs2Ptr = new Course();
        printCourse(*cs2Ptr);
        cs2Ptr->setCourseName(name);
        cs2Ptr->setDepartment(depart);
        cs2Ptr->setCredit(4);
        printCourse(*cs2Ptr);
    }
    cout << "\n\nEnter RRTURN key to finish the program";
    cin.get();
    return 0;
}

void printCourse(const ComputerScience::Course& a)
{
    cout << "\"" << a.getCourseName() << "\" of "
         << a.getDepartment() << " Department has "
         << a.getCredit() << " credits";
}