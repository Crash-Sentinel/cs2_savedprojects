/*
   COPYRIGHT (C) 2025 Bennett Miller ( 4804913 ) All rights reserved.
   CS assignment
   Author.  Bennett Miller
            bzm3@uakron.edu
   Version. 1.01 04/27/25
   Purpose: This program ...
*/
#ifndef TREE_HPP
#define TREE_HPP
#include <iostream>
#include "Treenode.hpp"

// Tree class-template definition
template<typename NODETYPE> class Tree {
public:
   // insert node in Tree
   void insertNode(const NODETYPE& value) {
      insertNodeHelper(&rootPtr, value);
   }

   // begin preorder traversal of Tree
   void preOrderTraversal() const {
      preOrderHelper(rootPtr);
   }

   // begin inorder traversal of Tree
   void inOrderTraversal() const {
      inOrderHelper(rootPtr);
   }

   // begin postorder traversal of Tree
   void postOrderTraversal() const {
      postOrderHelper(rootPtr);
   }

   // get the depth of the tree
   int getDepth() const {
      int totalDepth{-1};
      int currentDepth{-1};

      determineDepth(rootPtr, &totalDepth, &currentDepth);
      return totalDepth;
   }

   // begin binary search
   TreeNode<NODETYPE>* binaryTreeSearch(NODETYPE val) const {
      return binarySearchHelper(rootPtr, val);
   }

private:
   TreeNode<NODETYPE>* rootPtr{nullptr};

   // utility function called by insertNode; receives a pointer
   // to a pointer so that the function can modify pointer's value
   void insertNodeHelper(
      TreeNode<NODETYPE>** ptr, const NODETYPE& value) {
      // subtree is empty; create new TreeNode containing value
      if (*ptr == nullptr) {
         *ptr = new TreeNode<NODETYPE>(value);
      }
      else { // subtree is not empty
             // data to insert is less than data in current node
         if (value <= (*ptr)->data) {
            insertNodeHelper(&((*ptr)->leftPtr), value);
         }
         else {
            insertNodeHelper(&((*ptr)->rightPtr), value);
         }
      }
   }

   // utility function to perform preorder traversal of Tree
   void preOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         std::cout << ptr->data << ' '; // process node
         preOrderHelper(ptr->leftPtr); // traverse left subtree
         preOrderHelper(ptr->rightPtr); // traverse right subtree
      }
   }

   // utility function to perform inorder traversal of Tree
   void inOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         inOrderHelper(ptr->leftPtr); // traverse left subtree
         std::cout << ptr->data << ' '; // process node
         inOrderHelper(ptr->rightPtr); // traverse right subtree
      }
   }

   // utility function to perform postorder traversal of Tree
   void postOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         postOrderHelper(ptr->leftPtr); // traverse left subtree
         postOrderHelper(ptr->rightPtr); // traverse right subtree
         std::cout << ptr->data << ' '; // process node
      }
   }

   // calculate the depth of the tree
   //rootPtr: the pointer to the root of the tree or sub tree when called recursively
   //         passed from calling statement
   //totalDepthPtr: a pointer to point to an int variable, calculate and store the max depth of nodes traversed
   //currentDepthPtr: a pointer to point to an int variable, it is a middle step variable
   //                 to calculate and hold the depth of the node that rootPtr pointing to
   //postcondition: the value of the variable that totalDepthPtr pointing to is the height of the tree
   void determineDepth(TreeNode<NODETYPE> * rootPtr, int *totalDepthPtr, int *currentDepthPtr) const {
      // L, R, Root (so postorder)
      if (!rootPtr) {
         return;
      }

      *(currentDepthPtr)++;

      determineDepth(rootPtr->left, totalDepthPtr, currentDepthPtr);
      determineDepth(rootPtr->right, totalDepthPtr, currentDepthPtr);

      if (!rootPtr->leftPtr && !rootPtr->rightPtr)
      {
         
         if (*totalDepthPtr < *currentDepthPtr)
         {
            *totalDepthPtr = *currentDepthPtr;
         }
         
      }

      (*currentDepthPtr)--;
   }

   // do a binary search on the Tree, searching the value val within a tree of rootPtr
   TreeNode<NODETYPE>* binarySearchHelper(TreeNode<NODETYPE> *rootPtr, NODETYPE val) const{
      if (!rootPtr)
      {
         //rootPtr is nullptr
         return nullptr;
      }
      
      NODETYPE curVal = rootPtr->getData();

      if (curVal == val)
      {
         std::cout << val << " was found\n";
         return rootPtr;
      }

      std::cout << "Comparing " << curVal << " to " << val << "; ";
      
      
      if (curVal > val)
      {
         std::cout << "smaller, walk left\n";
         return binarySearchHelper(rootPtr->leftPtr, val);
      } else {
         std::cout << "larger, walk right\n";
         return binarySearchHelper(rootPtr->rightPtr, val);
      }

      return nullptr;
   }

};

#endif // TREE_HPP
