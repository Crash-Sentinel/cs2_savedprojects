#include "IntArray.h"
#include <iostream>
namespace ComputerScience
{
    void IntArray::addNodes(int num)
    {
        if (num < 0) return;
        
        ListNode *newNode;
        // add num nodes to the end of the list
        for (int i = 0; i < num; i++)
        {
            // create a node. Leave value unassigned because it is a placeholder
            newNode = new ListNode;
            newNode->next = nullptr;
            newNode->previous = nullptr;
            
            // add to the list
            if (last == nullptr)
            {
                // empty list
                first = last = newNode;
            }
            else
            {
                last->next = newNode; // make current last node pointing to newNode
                newNode->previous = last; // make newNode pointing back to current last node
                last = newNode; // make newNode becomes the last node
            }
        }
        
        length += num; // increase the length of the array
        // variables current and currentIndex are not impacted by adding nodes
        // but need to check if currentIndex is -1
        if (currentIndex < 0 && length > 0)
        {
            // make it pointing to first node
            currentIndex = 0;
            current = first;
        }
    }
    
    void IntArray::removeNodes(int num)
    {
        if (num < 0) return;
        
        // remove num nodes from the end of the list
        if (num > length)
            num = length; // num must be <= length
        
        ListNode *tmp;
        for (int i = 0; i < num; i++)
        {
            if (last->previous == nullptr)
            {
                // only one node remaining in the list
                delete last;
                first = last = nullptr;
            }
            else
            {
                tmp = last; // remember the last node
                
                // make next to the last be the last node
                last = last->previous; // moving back one node
                last->next = nullptr;
                
                delete tmp; // free the space
            }
        }
        
        length -= num; // decrease the length of the array
        
        if (currentIndex > length - 1)
        {
            // the node that variable current points to is removed
            // make the variable current point to last node
            current = last; // current could be nullptr if list is empty
            currentIndex = length - 1; // currentIndex could be -1 if list is empty
        }
    }
    
    IntArray::IntArray(int size)
    {
        length = 0;
        first = last = current = nullptr;
        currentIndex = -1;
        
        if (size < 0)
        {
            std::cout << "size of the array must be greater than 0";
        }
        else if (size == 0)
        {
            // do nothing because already initialized
        }
        else
        {
            addNodes(size); // add placeholders
            currentIndex = 0;
            current = first;
        }
    }
    
    IntArray::~IntArray()
    {
        removeNodes(length);
    }
    
    IntArray::IntArray(const IntArray &r)
    {
        length = 0;
        first = last = current = nullptr;
        currentIndex = -1;
        
        copyContent(r); // copy all
    }
    
    IntArray &IntArray::operator=(const IntArray &r)
    {
        if (this == &r)
        {
            // the address of itself is the same as the address of object a
            // it is doing a=a. So do nothing
            return *this;
        }
        
        removeNodes(length); // clean the list
        copyContent(r); // copy all
        return *this;
    }
    
    void IntArray::copyContent(const IntArray &r)
    {
        if (r.length == 0)
        {
            // do nothing. Current list is already cleaned before this function is called
        }
        else if (r.length > length)
        {
            // add placeholders
            addNodes(r.length - length);
        }
        else if (r.length < length)
        {
            // remove extra nodes
            removeNodes(length - r.length);
        }
        
        ListNode *n1 = first;
        ListNode *n2 = r.first;
        for (int i = 0; i < length; i++)
        {
            n1->value = n2->value;
            n1 = n1->next;
            n2 = n2->next;
        }
        
        currentIndex = 0;
        current = first;
    }
    
    int IntArray::size() const
    {
        return length;
    }
    
    int &IntArray::operator[](int i)
    {
        if (i < 0 || i >= length)
        {
            std::cout << "the index is out of range";
        }
        else
        {
            if (i == currentIndex + 1)
            {
                current = current->next;
                currentIndex++;
            }
            else if (i == currentIndex - 1)
            {
                current = current->previous;
                currentIndex--;
            }
            else
            {
                // find the closest node of first, current, and last, then move from the closest
                if (abs(i - 0) < abs(i - currentIndex))
                {
                    current = first;
                    currentIndex = 0;
                }
                else if (abs(i - (length - 1)) < abs(i - currentIndex))
                {
                    current = last;
                    currentIndex = length - 1;
                }
                
                if (i >= currentIndex)
                {
                    while (currentIndex != i)
                    {
                        current = current->next;
                        currentIndex++;
                    }
                }
                else
                {
                    while (currentIndex != i)
                    {
                        current = current->previous;
                        currentIndex--;
                    }
                }
            }
        }
        return current->value;
    }
    
    IntArray IntArray::operator+(const IntArray &r) const
    {
        IntArray merged(length + r.length);
        
        ListNode *p1 = merged.first;
        ListNode *p2 = first;
        for (int i = 0; i < length; i++)
        {
            p1->value = p2->value;
            p1 = p1->next;
            p2 = p2->next;
        }
        
        p2 = r.first;
        for (int i = 0; i < r.length; i++)
        {
            p1->value = p2->value;
            p1 = p1->next;
            p2 = p2->next;
        }
        
        return merged;
    }
    
    IntArray IntArray::operator+(int val) const
    {
        IntArray merged(length + 1);
        
        ListNode *p1 = merged.first;
        ListNode *p2 = first;
        for (int i = 0; i < length; i++)
        {
            p1->value = p2->value;
            p1 = p1->next;
            p2 = p2->next;
        }
        
        p1->value = val;
        return merged;
    }
    
    IntArray &IntArray::operator+=(const IntArray &r)
    {
        if (r.length == 0) return *this;
        
        ListNode *p1 = last;
        int rLength = r.length;
        addNodes(r.length);
        
        ListNode *p2 = r.first;
        for (int i = 0; i < rLength; i++)
        {
            p1->next->value = p2->value;
            p1 = p1->next;
            p2 = p2->next;
        }
        return *this;
    }
    
    IntArray &IntArray::operator+=(int val)
    {
        addNodes(1);
        last->value = val;
        return *this;
    }
    
    void IntArray::Resize(int newSize)
    {
        if (newSize <= 0)
        {
            std::cout << "array size must be a positive number";
            return;
        }
        if (newSize > length)
        {
            addNodes(newSize - length);
        }
        else
        {
            removeNodes(length - newSize);
        }
    }
    
    std::ostream &operator<<(std::ostream &out, const IntArray &r)
    {
        IntArray::ListNode *p = r.first;
        for (int i = 0; i < r.length; i++)
        {
            out << p->value << " ";
            p = p->next;
        }
        return out;
    }
    
    std::istream &operator>>(std::istream &in, IntArray &r)
    {
        IntArray::ListNode *p = r.first;
        for (int i = 0; i < r.length; i++)
        {
            in >> p->value;
            p = p->next;
        }
        return in;
    }
    
    IntArray IntArray::operator+(int val, const IntArray &r)
    {
        IntArray merged(r.length + 1);
        ListNode *p1 = merged.first;
        p1->value = val;
        p1 = p1->next;
        
        ListNode *p2 = r.first;
        for (int i = 0; i < r.length; i++)
        {
            p1->value = p2->value;
            p1 = p1->next;
            p2 = p2->next;
        }
        return merged;
    }
    
    IntArray::iterator IntArray::begin() //return the iterator pointing to the first node
    {
        iterator it(first);
        return it;
    }
    
    IntArray::iterator IntArray::end() //return the iterator pointing to an address a little more than the last node
    {
        if (last == nullptr)
        {
            iterator it;
            return it;
        }
        else
        {
            iterator it(last);
            return ++it; // re-use the ++ operator to get an address a little more than the last node
        }
    }
    
    //****  member functions of iterator
    IntArray::ListNode *IntArray::iterator::noWhere()
    {   
        // The list node contains an int (4 bytes) and two ListNode pointers (4 bytes each in 32-bits system or 8 bytes each in 64-bits system)
        // So an address between &ListNode + 1 byte and &ListNode + 11 bytes serves the purpose
        // since no other list node can be allocated there.
        // We use &ListNode + 3 bytes to do so

        //In order to make an address, we advance 3 bytes from the beginning address of the list node
        //we need to convert the pointer of ListNode to char pointer first
        //then convert back to ListNode pointer after adding 3

        //Directly adding 3 to the pointer of ListNode means to advance 3 blocks of ListNode memory.
        //It does not work because the address advanced may be allocated to other ListNodes
        return (ListNode*)((char*)p + 3); //p is the pointer to current ListNode.
            //i.e. the address of current ListNode,
            // or the address of the first byte of current ListNode
            //(char*): convert to the pointer of char.
            //(ListNode*): convert to the pointer of ListNode
    }
    
    IntArray::iterator::iterator(ListNode *ln) //constructor with a pointer of list node passed in.
        //ln is default to nullptr in the prototype. So it also contains a default constructor
    {
        p = ln;
    }
    
    bool IntArray::iterator::operator!=(const iterator &right) //overloading !=
    {
        return !(p == right.p);
    }
    
    bool IntArray::iterator::operator==(const iterator &right)
    {
        return p == right.p;
    }
    
    int &IntArray::iterator::operator*() //dereference operator.
        //It must return the reference of the member value to allow assigning values to *p
    {
        return p->value;
    }
    
    IntArray::iterator &IntArray::iterator::operator++() //prefix ++. Advancing Iterator
    {
        if (p->next == nullptr)
        {
            //p points to the last nodes
            //set p to noWhere() of the node
            p = noWhere();
        }
        else
        {
            p = p->next; //advancing
        }
        return *this;
    }
    
    IntArray::iterator IntArray::iterator::operator++(int) //postfix ++, parameter is a dummy parameter. Advancing Iterator
    {
        iterator it = *this;
        ++(*this); //advance current iterator by resuing prefix ++
        return it;
    }
    
    IntArray::iterator IntArray::iterator::operator+(int steps) //overloading +. Advancing iterator
                                                        // for that many steps specified by the parameter
    {
        iterator previousIt;
        iterator it = *this;
        //advancing
        for (int i = 0; i < steps && it.p != nullptr; i++)
        {
            previousIt = it;
            it.p = it.p->next;
        }
        if (it.p == nullptr)
        {
            //it reaches beyond the list range
            //previousIt now points to the last node
            return ++previousIt; //reusing prefix ++ to return an iterator pointing a little after the last node
        }
        else
        {
            return it;
        }
    }
    //*** end of iterator
}
