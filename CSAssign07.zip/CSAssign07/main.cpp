/*
Bennett Miller @ bzm3@uakron.edu
Purpose: display implementation of map, iterator, and pairs in C++ via movie ratings
*/

#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <iomanip>

int main ()
{
    //Obtain file and initialize frequently modified or accessed variables
    std::ifstream dfile("file.txt");
    std::map<std::string, std::pair<int, int>> ratings;
    std::string line;
    
    int numsItems = 0;

    
    // Read the first line and set numsItems to the first number in file.txt

    dfile >> numsItems;

    // loop through the file and update map based on criteria based in assignment
    // aka, fill the list with new pairs with <name, <frequency, sum>> values
    int placeholder = 0;
    while (getline(dfile, line))
    {
        getline(dfile, line);
        dfile >> placeholder;
        if (ratings.count(line)) 
        {
            const auto& value = ratings.at(line);
            ratings.at(line) = std::make_pair(value.first+1, value.second+placeholder);
        } else {
            ratings.emplace(line, std::make_pair(1, placeholder));
        }
    }
    
    // loop through the map and display average using iterators
    auto itr = ratings.begin();
    while (itr != ratings.end())
    {
        std::cout << std::setprecision(2);
        auto& pair = itr->second;
        std::cout << itr->first << ": " << pair.first << " review, average of " << static_cast<double>(pair.second) / pair.first << " / 5" << std::endl;
        itr++;
    }

    // complete algorithm
    return 0;
}