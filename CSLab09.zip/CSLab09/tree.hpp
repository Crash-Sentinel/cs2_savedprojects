/*
   COPYRIGHT (C) 2025 Bennett Miller ( 4804913 ) All rights reserved.
   CS assignment
   Author.  Bennett Miller
            bzm3@uakron.edu
   Version. 1.01 04/30/2025
   Purpose: Optimization of Binary Trees Lab 09
*/
#ifndef TREE_HPP
#define TREE_HPP
#include <iostream>
#include "Treenode.hpp"

// Tree class-template definition
template<typename NODETYPE> class Tree {
public:
   // insert node in Tree
   void insertNode(const NODETYPE& value) {
      insertNodeHelper(&rootPtr, value);
   }

   // begin preorder traversal of Tree
   void preOrderTraversal() const {
      preOrderHelper(rootPtr);
   }

   // begin inorder traversal of Tree
   void inOrderTraversal() const {
      inOrderHelper(rootPtr);
   }

   // begin postorder traversal of Tree
   void postOrderTraversal() const {
      postOrderHelper(rootPtr);
   }

   // get the depth of the tree
   int getDepth() const {
      int totalDepth{-1};
      int currentDepth{-1};

      determineDepth(rootPtr, &totalDepth, &currentDepth);
      return totalDepth;
   }

   // begin binary search
   TreeNode<NODETYPE>* binaryTreeSearch(NODETYPE val) const {
      return binarySearchHelper(rootPtr, val);
   }
   ~Tree(){
       deleteSubTree(rootPtr);
   }
   int Count() const{
       return countNodes(rootPtr);
   }
   void Optimize(){
       int numberOfNodes = Count();
       //create a new array with the size of the number of tree nodes
       NODETYPE *arr = new NODETYPE[numberOfNodes];

       //put node values to arr with in-order
       int index = 0;
       PopulateArrayInOrder(rootPtr, index, arr);

       //remove all tree nodes
       deleteSubTree(rootPtr);
       rootPtr = nullptr;

       //re insert, always in the order of middle element, elements of left half, elements of right half
       InsertFromTheSortedArray(arr, 0, numberOfNodes - 1);

       //free the memory of the array
       delete [] arr;
   }
private:
   TreeNode<NODETYPE>* rootPtr{nullptr};

   // utility function called by insertNode; receives a pointer
   // to a pointer so that the function can modify pointer's value
   void insertNodeHelper(
      TreeNode<NODETYPE>** ptr, const NODETYPE& value) {
      // subtree is empty; create new TreeNode containing value
      if (*ptr == nullptr) {
         *ptr = new TreeNode<NODETYPE>(value);
      }
      else { // subtree is not empty
             // data to insert is less than data in current node
         if (value <= (*ptr)->data) {
            insertNodeHelper(&((*ptr)->leftPtr), value);
         }
         else {
            insertNodeHelper(&((*ptr)->rightPtr), value);
         }
      }
   }

   // utility function to perform preorder traversal of Tree
   void preOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         std::cout << ptr->data << ' '; // process node
         preOrderHelper(ptr->leftPtr); // traverse left subtree
         preOrderHelper(ptr->rightPtr); // traverse right subtree
      }
   }

   // utility function to perform inorder traversal of Tree
   void inOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         inOrderHelper(ptr->leftPtr); // traverse left subtree
         std::cout << ptr->data << ' '; // process node
         inOrderHelper(ptr->rightPtr); // traverse right subtree
      }
   }

   // utility function to perform postorder traversal of Tree
   void postOrderHelper(TreeNode<NODETYPE>* ptr) const {
      if (ptr != nullptr) {
         postOrderHelper(ptr->leftPtr); // traverse left subtree
         postOrderHelper(ptr->rightPtr); // traverse right subtree
         std::cout << ptr->data << ' '; // process node
      }
   }

   // calculate the depth of the tree
   //rootPtr: the pointer to the root of the tree or sub tree when called recursively
   //         passed from calling statement
   //totalDepthPtr: a pointer to point to an int variable, calculate and store the max depth of nodes traversed
   //currentDepthPtr: a pointer to point to an int variable, it is a middle step variable
   //                 to calculate and hold the depth of the node that rootPtr pointing to
   //postcondition: the value of the variable that totalDepthPtr pointing to is the height of the tree
   void determineDepth(TreeNode<NODETYPE> * rootPtr, int *totalDepthPtr, int *currentDepthPtr) const {
        if(rootPtr == nullptr)
            return;
        (*currentDepthPtr)++;
        if(*totalDepthPtr < *currentDepthPtr)
            *totalDepthPtr = *currentDepthPtr;
        //std::cout << std::endl << rootPtr->getData() << ' ' << *totalDepthPtr << ' ' << *currentDepthPtr;
        determineDepth(rootPtr->getLeftPtr(), totalDepthPtr, currentDepthPtr);
        determineDepth(rootPtr->getRightPtr(), totalDepthPtr, currentDepthPtr);
        (*currentDepthPtr)--;
        return;
   }

   // do a binary search on the Tree, searching the value val within a tree of rootPtr
   TreeNode<NODETYPE>* binarySearchHelper(TreeNode<NODETYPE> *rootPtr, NODETYPE val) const{
        if(rootPtr == nullptr) return nullptr;
        if(rootPtr->getData() == val) return rootPtr;
        if(val <= rootPtr->getData())
            return binarySearchHelper(rootPtr->getLeftPtr(), val);
        else
            return binarySearchHelper(rootPtr->getRightPtr(), val);

   }

   //count the nodes of the tree starting from the root node rootPtr
   int countNodes(TreeNode<NODETYPE> *rootPtr) const{
       if(rootPtr == nullptr)
          return 0;
       return 1 + countNodes(rootPtr->getLeftPtr()) + countNodes(rootPtr->getRightPtr());
   }
   //clean the nodes of the tree starting from the root node rootPtr
   void deleteSubTree(TreeNode<NODETYPE> *rootPtr)
   {
       if(rootPtr == nullptr)
          return;
       deleteSubTree(rootPtr->getLeftPtr());
       deleteSubTree(rootPtr->getRightPtr());
       //free up the momory of itself
       delete rootPtr;
   }

   //traverse the tree with in-order method. Put the values into the array
   //since it is in-order, the values in the array are small to large sorted
   //precondition: subTreeRootPtr is the root node of the tree. It starts from the root node of the whole tree
   //              index is the array index which holds the value of the node subTreeRootPtr. It starts from 0, then increments
   //              arr is the array to hold values of all nodes
   //postcondition: when finished, arr holds values of all nodes in sorted order
   void PopulateArrayInOrder(TreeNode<NODETYPE> * subTreeRootPtr, int &index, NODETYPE arr[]) const{
       if(subTreeRootPtr == nullptr) return;
       PopulateArrayInOrder(subTreeRootPtr->getLeftPtr(), index, arr); //populate left sub tree
       arr[index++] = subTreeRootPtr->getData();  //populate me
       PopulateArrayInOrder(subTreeRootPtr->getRightPtr(), index, arr); //populate right sub tree
   }

   //insert values from array arr to the tree. The insertion order is the value of the middle position, left sub tree and then right right sub tree
   //startIndex and endIndex is the range of positions that values are taken from the array to insert to the tree
   void InsertFromTheSortedArray(NODETYPE arr[], int startIndex, int endIndex){
       if(endIndex < startIndex) return;
       int mid = (startIndex + endIndex) / 2;
       insertNode(arr[mid]);
       InsertFromTheSortedArray(arr, startIndex, mid - 1);
       InsertFromTheSortedArray(arr, mid + 1, endIndex);
   }
};

#endif // TREE_HPP
