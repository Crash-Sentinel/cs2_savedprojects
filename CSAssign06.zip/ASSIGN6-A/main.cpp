// This program demonstrates the MathStack class.
#include <iostream>
#include "Stack.cpp"


int main()
{
   int catchVar;  // To hold values popped off the stack

   // Create a MathStack object.
   Stack stack(5);

   // Push 3 and 6 onto the stack.
   std::cout << "Pushing 3\n";
   stack.push(3);
   std::cout << "Pushing 6\n";
   stack.push(6);

   // Add the two values.
   stack.add();

   // Pop the sum off the stack and display it.
   std::cout << "The sum is ";
   stack.pop(catchVar);
   std::cout << catchVar << std::endl << std::endl;

   // Push 7 and 10 onto the stack
   std::cout << "Pushing 7\n";
   stack.push(7);
   std::cout << "Pushing 10\n";
   stack.push(10);

   // Subtract 7 from 10.
   stack.sub();

   // Pop the difference off the stack and display it.
   std::cout << "The difference is ";
   stack.pop(catchVar);
   std::cout << catchVar << std::endl;

   /*
      implementation below:
   */

   std::cout << "My implementation:\nPushing 4\n";
   stack.push(4);
   std::cout << "Pushing 6:\n";
   stack.push(6);
   
   stack.mult();

   stack.pop(catchVar);
   std::cout << "The product is: " << catchVar << "\n\n";

   std::cout << "Pushing 5\n";
   stack.push(5);
   std::cout << "Pushing 5:\n";
   stack.push(5);
   
   stack.mult();

   stack.pop(catchVar);
   std::cout << "The product is: " << catchVar << "\n\n";
   
   std::cout << "Pushing 12\n";
   stack.push(12);
   std::cout << "Pushing 6:\n";
   stack.push(6);
   
   stack.div();

   stack.pop(catchVar);
   std::cout << "The quotient is: " << catchVar << "\n\n";
   
   std::cout << "Pushing 24\n";
   stack.push(24);
   std::cout << "Pushing 8:\n";
   stack.push(8);
   
   stack.div();

   stack.pop(catchVar);
   std::cout << "The quotient is: " << catchVar << "\n\n";
   
   std::cout << "Pushing 3\n";
   std::cout << "Pushing 4\n";
   std::cout << "Pushing 5\n";

   stack.push(3);
   stack.push(4);
   stack.push(5);

   std::cout << "The sum of all is: \n";
   stack.addAll();
   stack.pop(catchVar);
   std::cout << catchVar << "\n\n";

   std::cout << "Pushing 3\n";
   std::cout << "Pushing 4\n";
   std::cout << "Pushing 5\n";

   stack.push(10);
   stack.push(18);
   stack.push(-5);

   std::cout << "The sum of all is: \n";
   stack.addAll();
   stack.pop(catchVar);
   std::cout << catchVar << "\n\n";

   std::cout << "Pushing 2\n";
   std::cout << "Pushing 2\n";
   std::cout << "Pushing 2\n";

   stack.push(2);
   stack.push(2);
   stack.push(2);

   std::cout << "The product of all is: \n";
   stack.multAll();
   stack.pop(catchVar);
   std::cout << catchVar << "\n\n";

   std::cout << "Pushing -3\n";
   std::cout << "Pushing 7\n";
   std::cout << "Pushing -5\n";

   stack.push(-3);
   stack.push(7);
   stack.push(-5);

   std::cout << "The product of all is: \n";
   stack.multAll();
   stack.pop(catchVar);
   std::cout << catchVar << "\n\n";

   return 0;
}
