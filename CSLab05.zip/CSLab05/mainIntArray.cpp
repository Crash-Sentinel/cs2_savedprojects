#include <iostream>
#include "IntArray.h"

/*
Name : Bennett Miller bzm3@uakron.edu
Purpose: Display more actualization in classes, dynamic memory, and reference operations
*/

using namespace std;

int main() {
    using namespace ComputerScience;

    IntArray a(3);
    
    // Test >> operator
    cout << "test operator >>" << endl;
    cout << "enter " << a.size() << " integers separated by empty space: ";
    cin >> a;
    
    // Test << operator
    cout << endl;
    cout << "test operator <<" << endl;
    cout << "echo entered values: " << a << endl;
    
    // Test [] operator
    cout << endl;
    cout << "test operator [] by setting the first element to 22" << endl;
    a[0] = 22;
    cout << "after first element changed to 22, the array is " << a << endl;
    
    // Test copy constructor
    cout << endl;
    cout << "test copy constructor." << endl;
    cout << "IntArray b(a)" << endl;
    IntArray b(a);
    cout << "a: " << a << endl;
    cout << "b: " << b << endl;
    
    // Test assignment operator
    cout << endl;
    cout << "test assignment c = a;" << endl;
    IntArray c(1);
    c = a;
    cout << "a: " << a << endl;
    cout << "c: " << c << endl;
    
    // Test operator+
    cout << endl;
    cout << "test c = a + b;" << endl;
    b[2] = 100;
    c = a + b;
    cout << "a: " << a << endl;
    cout << "b: " << b << endl;
    cout << "c: " << c << endl;
    
    // Test operator+(int)
    cout << endl;
    cout << "test c = a + 230" << endl;
    c = a + 230;
    cout << "a: " << a << endl;
    cout << "c = a + 230: " << c << endl;
    
    // Test operator+= (IntArray)
    cout << endl;
    cout << "test a += c" << endl;
    cout << "a: " << a << endl;
    cout << "c: " << c << endl;
    a += c;
    cout << "after a += c, a is " << a << endl;
    
    // Test operator+= (int)
    cout << endl;
    cout << "test a += 600" << endl;
    cout << "a: " << a << endl;
    a += 600;
    cout << "after a += 600, a is " << a << endl;
    
    // Test friend operator+(int, IntArray)
    cout << endl;
    cout << "test c = 710 + a" << endl;
    c = 710 + a;
    cout << "a: " << a << endl;
    cout << "after c = 710 + a, c is " << c << endl;
    
    return 0;
}
