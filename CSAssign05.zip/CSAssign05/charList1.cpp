/*
   COPYRIGHT (C) 2024 Bennett Miller ( 4804913 ) All rights reserved.
   CSII assignment 5 A
   Author.  Bennett Miller
            bzm3@uakron.edu
   Version. 1.01 03.05.2025

   NOTE: makefile is meant to help me compile and test code more efficiently,
   if you desire you can take a look into it but it doesn't contribute to the functionality of the code

*/
// Implementation file for the NumberList class

// Your coding required here 
#include "charList.hpp"
#include <iostream>

CharList::CharList(char val)
{

   ListNode* node = new ListNode(val);

   head = node;

   node->next = nullptr;
}

CharList::CharList()
{
   head = nullptr;
}


//**************************************************
// displayList shows the value                     *
// stored in each node of the linked list          *
// pointed to by head.                             *
// pre: an empty parameter list                    *
// post: standard output of the linked list        *
//**************************************************

void CharList::displayList() const
{
   ListNode *nodePtr;  // To move through the list

   // Position nodePtr at the head of the list.
   nodePtr = head;
   short count = 0;

   // While nodePtr points to a node, traverse
   // the list.
   while (nodePtr)
   {
      // Display the value in this node.
      std::cout << "[" << nodePtr->value << "] -> ";
      ++count;
      // Move to the next node.
      nodePtr = nodePtr->next;
      if (count % 10 == 0) {
        std::cout << std::endl;
        count = 0;
      }
   }
   std::cout << std::endl;
}


// More of your coding required here 


//**************************************************
// Destructor                                      *
// This function deletes every node in the list.   *
// pre: n/a                                        *
// post: destroyed object                          *
//**************************************************

CharList::~CharList()
{
   ListNode *nodePtr;   // To traverse the list
   ListNode *nextNode;  // To point to the next node

   // Position nodePtr at the head of the list.
   nodePtr = head;

   // While nodePtr is not at the end of the list...
   while (nodePtr != nullptr)
   {
      // Save a pointer to the next node.
      nextNode = nodePtr->next;

      // Delete the current node.
      delete nodePtr;

      // Position nodePtr at the next node.
      nodePtr = nextNode;
   }
}

//**************************************************
// Append a node                                   *
// This function appends a new node in the list.   *
// pre: char to create a new pointer               *
// post: appended node to the end of the list      *
//**************************************************
void CharList::appendNode(char value)
{
   ListNode* node = new ListNode(value);

   if (!head) //if head points to null, aka is an empty list
   {
      node->next = nullptr;
      head = node;
      return;
   }

   ListNode* curPtr = head; // else traverse through the list until the end, then make the last node point to the new last node

   while (curPtr->next != nullptr)
   {
      curPtr = curPtr->next;
   }

   curPtr->next = node;
   node->next = nullptr;
}


//**************************************************
// Inserts a node in descending order              *
// This function inserts a new node in the list.   *
// pre: char to create a new pointer               *
// post: Inserted node to the appropriate position *
//**************************************************
void CharList::insertNode(char value)
{
   ListNode* node = new ListNode(value);

   if (head == nullptr) // if the list is empty, insert the node
   {
      head->next = node;
      node->next = nullptr;
      return;
   }

   if (head->value < value) // if the first node is less than the new node, make the new node the head
   {
      node->next = head;
      head = node;
      return;
   }

   ListNode* curPtr = head; // else traverse through the list and find the proper location for descending order
   ListNode* prevPtr = nullptr;

   while (curPtr != nullptr && curPtr->value > value)
   {
      prevPtr = curPtr;
      curPtr = curPtr->next;
   }

   prevPtr->next = node;
   node->next = curPtr;
}

//**************************************************************
// Deletes the first node associated to value                  *
// This function deletes the first 'value' node in the list.   *
// pre: char to find node                                      *
// post: Deleted node to the list                              *
//**************************************************************
void CharList::deleteNode(char value)
{
   if (head->next == nullptr) // if list is empty, we cannot remove anything
   {
      return;
   }

   if (head->value == value) //if the desired node is the head, push the new head forward and delete the previous head
   {
      ListNode* temp = head;
      head = head->next;
      delete temp;
      return;
   }

   ListNode* curptr = head; // else, traverse through the list, remove dangling pointers and connect the previous and next nodes together and then free the memory allocated to the desired delete node
   ListNode* prevPtr = nullptr;
   while (curptr->next != nullptr && curptr->value != value)
   {
      prevPtr = curptr;
      curptr = curptr->next;
   }

   if (curptr == nullptr)
   {
      return;
   }

   prevPtr->next = curptr->next;
   delete curptr;
}