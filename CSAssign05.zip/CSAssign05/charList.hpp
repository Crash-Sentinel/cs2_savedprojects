#ifndef CHARLIST_HPP
#define CHARLIST_HPP

//Standard ListNode struct for creating nodes
struct ListNode
{
    char value;
    ListNode* next;

    ListNode(char val) : value(val), next(nullptr) {};
};

//CharList class prototype
class CharList
{
    private:
        ListNode* head;
    public:
        CharList(); 
        CharList(char); 
        ~CharList();

        void displayList() const;
        void appendNode(char);
        void insertNode(char);
        void deleteNode(char);
};

#endif