#include "Complex.hpp"
#include <iostream>

// Constructor definition
Complex::Complex(double realPart, double imaginaryPart) : realPart(realPart), imaginaryPart(imaginaryPart) {}

// Overload the + operator
Complex Complex::operator+(const Complex &operand2) const {
    // Placeholder for implementation
    double real = this->realPart + operand2.realPart;
    double imag = this->imaginaryPart + operand2.imaginaryPart;
    return Complex(real, imag);
}

// Overload the - operator
Complex Complex::operator-(const Complex &operand2) const {
    // Placeholder for implementation
    double real = this->realPart - operand2.realPart;
    double imag = this->imaginaryPart - operand2.imaginaryPart;
    return Complex(real, imag);
}

// Overload the * operator
Complex Complex::operator*(const Complex &operand2) const {
    // Placeholder for implementation

    // After not being so sure about how the numbers were coming up, I looked up how complex numbers were
    // multiplied and got this equation to then implement into code:
    // a+bi * c+di = ((a * c) - (b * d)) + ((a*d) + (b*c)) i
    double real = (this->realPart * operand2.realPart) - (this->imaginaryPart * operand2.imaginaryPart);
    double imag = (this->realPart * operand2.imaginaryPart) + (this->imaginaryPart * operand2.realPart);
    return Complex(real, imag);
}

// Overload the = operator
Complex& Complex::operator=(const Complex &rhs) {
    // Placeholder for implementation
    this->realPart = rhs.realPart;
    this->imaginaryPart = rhs.imaginaryPart;
    return *this;
}

// Overload the == operator
bool Complex::operator==(const Complex &rhs) const {
    // Placeholder for implementation
    return (this->realPart == rhs.realPart && this->imaginaryPart == rhs.imaginaryPart); 
}

// Overload the != operator
bool Complex::operator!=(const Complex &rhs) const {
    // Placeholder for implementation
    return !(*this == rhs);
}

// Overload the >> operator as a friend function
std::istream &operator>>(std::istream &in, Complex &complex) {
    // Placeholder for implementation
    in >> complex.realPart >> complex.imaginaryPart;
    return in;
}

// Overload the << operator as a friend function
std::ostream &operator<<(std::ostream &out, const Complex &complex) {
    // Placeholder for implementation
    out << "Complex Number: " << complex.realPart << " + " << complex.imaginaryPart << "i\n";
    return out; 
}