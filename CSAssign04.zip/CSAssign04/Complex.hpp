#ifndef COMPLEX_HPP
#define COMPLEX_HPP
#include <string>

/*
Name: Bennett Miller bzm3@uakron.edu
Purpose of Program: Implementation of Operator Overloading given a class
*/


/*
Complex class, some member functions are present however
all operator overloading post those are mine. They all follow general same
preconditions and post for standard operator overloading except the insertion and extraction operators respectively
*/
class Complex
{
public:
   Complex(double = 0.0, double = 0.0); // default constructor
   Complex add(const Complex&) const;			  // function add
   Complex subtract(const Complex&) const; // function subtract
   Complex multiply(const Complex&) const; // function multiply
   void setComplexNumber(double, double); // set complex number

   Complex operator+(const Complex &operand2) const;
   Complex operator-(const Complex &operand2) const;
   Complex operator*(const Complex &operand2) const;
   Complex &operator=(const Complex &rhs);
   bool operator==(const Complex &rhs) const;
   bool operator!=(const Complex &rhs) const;
   friend std::istream& operator>>(std::istream& is, Complex& complex);
   friend std::ostream& operator<<(std::ostream& os, const Complex& complex);
   
private:
   double realPart;
   double imaginaryPart;
};

#endif

