#include "./deleteRepeats.hpp"

#include <iostream>
#include <memory>

std::unique_ptr<char[]> deleteRepeats(char* arr)
{
    // Avoiding std::set or other data structures since I figured they weren't encouraged
    // for this kind of project, if they were then just use loop through the array and add each value
    // to the set, then transform that set into a dynamic array then a smart ptr to point to first value
    int predictedFullSize = 0;
    
    for (int i = 0; *(arr+i) != '\0'; ++i)
    {
        predictedFullSize++; // Predict the size of the argued array (not fully accurate but just enough to make space)
    }
    
    char temp[predictedFullSize];
    int uniqueCount = 0;
    
    // Try to remove duplicates by skipping over them 
    // and saving originals to temp while increasing unique count for later
    for (int i = 0; i < predictedFullSize; ++i)
    {
        bool isDup = false;
        
        for (int j = 0; j < uniqueCount; ++j)
        {
            if (arr[i] == temp[j])
            {
                isDup = true;
                break;
            }
        }
        
        if (!isDup)
        {
            temp[uniqueCount++] = arr[i];
        }
    }
    
    // Set each unique value to result smart ptr and include a termination sentinel
    // Return that smart ptr 
    std::unique_ptr<char[]> result(new char[uniqueCount+1]);
    
    for (int i = 0; i < uniqueCount; ++i)
    {
        result[i] = temp[i];
    }
    result[uniqueCount] = '\0';
    
    return result;
}
