/*
Author: Bennett Miller

Purpose: Craft the definition of deleteRepeats to remove duplicates from an array and then
display the amount of values removed
*/
#include <iostream>
#include "./deleteRepeats.cpp"

// No-named namespace as required by assignment
namespace
{
    const int SIZE = 10;
}

int main ()
{
    // Main driver code:

    // Applied driver code as assignment:
    //Not having an \0 termination here is probably what's causing the error to happen, 
    //is there something else that I am missing here?
    char originalArray[SIZE];
    originalArray [0] = 'a';
    originalArray [1] = 'b';
    originalArray [2] = 'b';
    originalArray [3] = 'c';
    originalArray [4] = 'a';
    originalArray [5] = 'c';
    originalArray [6] = 'a';
    originalArray [7] = 'c';
    originalArray [8] = 'b';
    originalArray [9] = 'c';
    auto noRepeats = deleteRepeats(originalArray); // Added auto for functionality

    int sizeForNoRepeats = 0;
    // Print out values from noRepeats
    // increment sizeForNoRepeats since it'll be used to check values removed
    // This doesn't read the \0 termination char and I'm not sure why, is there something that I'm missing as well here?
    for (int i = 0; *(noRepeats.get() + i) != '\0'; ++i)
    {
        std::cout << noRepeats[i] << std::endl;
        sizeForNoRepeats++;
    }

    //Wasn't sure whether we were allowed to use the SIZE in namespace
    //Print out how many values removed
    // sizeof(array) / sizeof(array[0]) -> length of array
    std::cout << "Values removed: " << sizeof(originalArray) / sizeof(originalArray[0])
     - sizeForNoRepeats << std::endl;

    
    return 0;
}
