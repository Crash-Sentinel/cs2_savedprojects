#ifndef DELETEREPEATS_H
#define DELETEREPEATS_H

#include <memory>
std::unique_ptr<char[]> deleteRepeats(char* arr);

#endif